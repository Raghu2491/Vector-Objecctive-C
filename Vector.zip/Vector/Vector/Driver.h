//
//  Driver.h
//  Vector
//  Course:CIS651
//  Assignment 1
//  Created by Raghavendra Jayaramegowda on 9/15/15.
//  Copyright (c) 2015 Raghavendra Jayaramegowda. All rights reserved.

#import <Foundation/Foundation.h>

@interface Driver : NSObject

+ (void)testingScenario;

@end
