//
//  SimpleVector.h
//  Vector
//  Course:CIS651
//  Assignment 1
//  Created by Raghavendra Jayaramegowda on 9/15/15.
//  Copyright (c) 2015 Raghavendra Jayaramegowda. All rights reserved.

#import <Foundation/Foundation.h>

@interface SimpleVector : NSObject

- (NSUInteger)size;
- (BOOL)addItem:(int)item;
- (int)getItemAtIndex:(NSUInteger)index;
- (BOOL)removeItemWithValue:(int)value;
- (NSUInteger)indexOfItemWithValue:(int)value;
- (BOOL)isEmpty;
- (NSString *) description;
- (void) print;

@end
