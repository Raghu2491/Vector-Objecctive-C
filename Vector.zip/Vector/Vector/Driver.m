//
//  Driver.m
//  Vector
//  Course:CIS651
//  Assignment 1
//  Created by Raghavendra Jayaramegowda on 9/15/15.
//  Copyright (c) 2015 Raghavendra Jayaramegowda. All rights reserved.


#import "Driver.h"
#import "SimpleVector.h"

@implementation Driver

+ (void)testingScenario {
    NSLog( @"Testing Started" );
    SimpleVector * a = [SimpleVector new];
    
    // show initial size and capacity of SimpleVector a and b
    NSLog( @"Size of SimpleVector a: %lu\n", (unsigned long)a.size );
    
    // add 10 items to SimpleVector a (add at the end of the list)
    for ( int i = 0;  i < 10;  ++i ) {
        [a addItem:i];
        NSLog( @"Added %d, Size of SimpleVector a: %lu\n", i, (unsigned long)a.size );
    }
    
    for ( NSUInteger i = 0;  i < a.size;  ++i ) { // here is NSUInteger for type compliance with index
        NSLog( @"Item at index %lu = %d\n", (unsigned long)i, [a getItemAtIndex:i] );
    }
    
    // remove an item from SimpleVector a
    NSUInteger index = 5;
    int item = [a getItemAtIndex:index];
    BOOL k = [a removeItemWithValue:item];
    NSString * message = [NSString stringWithFormat:@"%@ item at index %lu, Size of SimpleVector a: %lu\n", (k ? @"Removed" : @"Failed to remove"), (unsigned long)index, (unsigned long)a.size];
    NSLog( @"%@", message );
    for ( NSUInteger i = 0;  i < a.size;  ++i ) {
        NSLog(@"Item at index %lu = %d\n", (unsigned long)i, [a getItemAtIndex:i]);
    }
    
    // insert an item at a particular position in SimpleVector a
    [a addItem:999];
    NSLog(@"Added %d at index %lu, Size of SimpleVector a: %lu\n", 999, (unsigned long)[a indexOfItemWithValue:999], (unsigned long)a.size );
    for ( NSUInteger i = 0;  i < a.size;  ++i ) {
        NSLog( @"Item at index %lu = %d\n", (unsigned long)i, [a getItemAtIndex:i] );
    }
    
    // clear out SimpleVector a (remove from end for efficiency)
    while ( a.size != 0 ) {
        [a removeItemWithValue:[a getItemAtIndex:(a.size - 1)]];
    }
    
    // check clear
    if ( a.isEmpty )
        NSLog( @"SimpleVector a is now empty" );
    else
        NSLog( @"SimpleVector a now contains %lu items\n", (unsigned long)a.size );
    
    }

@end
