//
//  SimpleVector.m
//  Vector
//  Course:CIS651
//  Assignment 1
//  Created by Raghavendra Jayaramegowda on 9/15/15.
//  Copyright (c) 2015 Raghavendra Jayaramegowda. All rights reserved.


#import "SimpleVector.h"

@interface SimpleVector()

@property (nonatomic, strong) NSMutableArray * ra;

@end

@implementation SimpleVector

- (instancetype)init {
    self = [super init];
    if (self) {
        self.ra = [NSMutableArray array];
        // we don't need to handle capacity manually in Objective-C. System will manage needed amount of memory in runtime itself.
    }
    return self;
}

- (NSUInteger)size {
    return [self.ra count];
}

- (BOOL)addItem:(int)item {
    [self.ra addObject:@(item)];
    // Due to functionality of NSMutableArray object will be added to the end of array by default, so there is no need to make this manually
    return YES;
}

- (int)getItemAtIndex:(NSUInteger)index {
    if (index < self.size) { // index can't be < 0 by its type
        return [[self.ra objectAtIndex:index] intValue];
    }
    return 0;
}

- (BOOL)removeItemWithValue:(int)value {
    NSValue * targetValue = @(value);
    __block BOOL deletionSuccessful = NO;
    __block NSValue * itemToDelete = nil;
    [self.ra enumerateObjectsUsingBlock:^(NSValue * item, NSUInteger idx, BOOL *stop) {
        if ([item isEqualToValue:targetValue]) {
            deletionSuccessful = YES;
            itemToDelete = item;
            *stop = YES;
        }
    }];
    if (itemToDelete) {
        [self.ra removeObject:itemToDelete];
    }
    return deletionSuccessful;
    // Again, size is maintained by NSMutableArray, so we don't need to handle it manually
}

- (NSUInteger)indexOfItemWithValue:(int)value {
    NSValue * targetValue = @(value);
    __block NSUInteger index = NSNotFound; // Objective-C equal for -1 in Java source
    [self.ra enumerateObjectsUsingBlock:^(NSValue * item, NSUInteger idx, BOOL *stop) {
        if ([item isEqualToValue:targetValue]) {
            index = idx;
            *stop = YES;
        }
    }];
    return index;
}

- (BOOL)isEmpty {
    return ([self.ra count] == 0);
}
//Display and Print Function
- (NSString *) description
{
    NSString *stringdes=@"SimpleVector is empty";
    return stringdes;
}
- (void) print
{
    if([self size]==0)
        NSLog(@"SimpleVector is empty \n");
    else
        NSLog(@"element in SimpleVector is %@ \n",[self.ra lastObject]);
}

@end
